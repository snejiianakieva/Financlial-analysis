#!/bin/bash

java -cp ./bin:./bin/plexus-classworlds-2.5.2.jar org.codehaus.plexus.classworlds.launcher.Launcher
