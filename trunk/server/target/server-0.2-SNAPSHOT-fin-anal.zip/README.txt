1. Unzip the archive
2. Make sure you have installed JRE 1.8 or higher
3. Configure the server by editing the etc/settings.properties file
4. Start the server.sh (or server.bat) script
4.1. Type start/stop to start/stop the web server
4.2. Type help for more info